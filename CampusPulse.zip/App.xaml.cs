using System.Windows;

namespace CampusPulse
{
    public partial class App : Application
    {
    }
}

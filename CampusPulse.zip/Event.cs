namespace CampusPulse
{
    public class Event
    {
        public string Title { get; set; } = "";
        public string When { get; set; } = "";
        public string Location { get; set; } = "";
        public string Category { get; set; } = "";
        public int Attendees { get; set; } = 0;
    }
}

using System.Collections.Generic;

namespace CampusPulse
{
    public static class DataStore
    {
        public static List<Event> Events { get; } = new List<Event>()
        {
            new Event {
                Title = "Research Methods Workshop",
                When = "Sun, 26 Oct 2025 12:00",
                Location = "Library Room 201",
                Category = "Academic",
                Attendees = 0
            },
            new Event {
                Title = "Open Mic Night",
                When = "Tue, 28 Oct 2025 17:30",
                Location = "Student Centre Hall",
                Category = "Cultural",
                Attendees = 0
            },
            new Event {
                Title = "Football Match",
                When = "Sat, 25 Oct 2025 14:00",
                Location = "Main Field",
                Category = "Sports",
                Attendees = 0
            }
        };
    }
}

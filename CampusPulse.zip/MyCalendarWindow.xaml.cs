using System.Linq;
using System.Windows;

namespace CampusPulse
{
    public partial class MyCalendarWindow : Window
    {
        private string _email;

        public MyCalendarWindow(string email)
        {
            InitializeComponent();
            _email = email;
            LoadMyEvents();
        }

        private void LoadMyEvents()
        {
            // MY CALENDAR SHOWS ONLY RSVP'D EVENTS
            var myEvents = DataStore.Events.Where(e => e.Attendees > 0).ToList();
            dgMyEvents.ItemsSource = myEvents;
        }

        private void Vote_Click(object sender, RoutedEventArgs e)
        {
            if (cmbPoll.SelectedItem is System.Windows.Controls.ComboBoxItem item)
            {
                MessageBox.Show($"Thanks! You voted for: {item.Content}");
            }
            else
            {
                MessageBox.Show("Please choose an option before voting.");
            }
        }
    }
}

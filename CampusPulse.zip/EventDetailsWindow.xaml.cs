using System.Windows;

namespace CampusPulse
{
    public partial class EventDetailsWindow : Window
    {
        private Event _event;

        public EventDetailsWindow(Event selectedEvent)
        {
            InitializeComponent();
            _event = selectedEvent;
            LoadDetails();
        }

        private void LoadDetails()
        {
            lblTitle.Text = _event.Title;
            lblWhen.Text = $"When: {_event.When}";
            lblLocation.Text = $"Location: {_event.Location}";
            lblCategory.Text = $"Category: {_event.Category}";

            lstAttendees.Items.Clear();
            for (int i = 0; i < _event.Attendees; i++)
            {
                lstAttendees.Items.Add($"Student #{i + 1}");
            }
        }

        private void btnRSVP_Click(object sender, RoutedEventArgs e)
        {
            // Toggle RSVP
            if (btnRSVP.Content.ToString() == "RSVP")
            {
                _event.Attendees++;
                btnRSVP.Content = "Cancel RSVP";
                MessageBox.Show("You have RSVPed.");
            }
            else
            {
                if (_event.Attendees > 0)
                    _event.Attendees--;
                btnRSVP.Content = "RSVP";
                MessageBox.Show("RSVP cancelled.");
            }

            LoadDetails();
        }
    }
}

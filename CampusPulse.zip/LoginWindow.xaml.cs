using System.Windows;

namespace CampusPulse
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            string email = txtEmail.Text.Trim();

            // Basic institutional email validation
            if (!email.EndsWith("@rcconnect.co.za") || !email.Contains("st"))
            {
                var res = MessageBox.Show("Email not recognized. Register new user?", "Register", MessageBoxButton.YesNo);
                if (res == MessageBoxResult.Yes)
                {
                    MessageBox.Show("Registration feature coming soon.");
                }
                return;
            }

            // Successful login
            DashboardWindow dash = new DashboardWindow(email);
            dash.Show();
            this.Close();
        }

        private void Help_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Enter your student email ending with @rcconnect.co.za");
        }
    }
}

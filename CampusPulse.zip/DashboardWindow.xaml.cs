using System.Linq;
using System.Windows;

namespace CampusPulse
{
    public partial class DashboardWindow : Window
    {
        private string LoggedInEmail;

        public DashboardWindow(string email)
        {
            InitializeComponent();
            LoggedInEmail = email;
            lblWelcome.Text = $"Welcome, {email}";
            LoadEvents();
        }

        private void LoadEvents()
        {
            dgEvents.ItemsSource = DataStore.Events.ToList();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            LoadEvents();
        }

        private void cmbFilter_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (cmbFilter.SelectedItem is System.Windows.Controls.ComboBoxItem item)
            {
                string category = item.Content.ToString();
                if (category == "All")
                    dgEvents.ItemsSource = DataStore.Events;
                else
                    dgEvents.ItemsSource = DataStore.Events.Where(ev => ev.Category == category);
            }
        }

        private void ViewDetails_Click(object sender, RoutedEventArgs e)
        {
            if (dgEvents.SelectedItem is Event ev)
            {
                EventDetailsWindow details = new EventDetailsWindow(ev);
                details.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select an event first.");
            }
        }

        private void MyCalendar_Click(object sender, RoutedEventArgs e)
        {
            MyCalendarWindow cal = new MyCalendarWindow(LoggedInEmail);
            cal.ShowDialog();
        }
    }
}
